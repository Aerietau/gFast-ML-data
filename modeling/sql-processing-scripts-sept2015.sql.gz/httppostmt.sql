-- Downstream throughput
--
-- This script produces results for downstream throughput measurements.
-- This script is more complex than others because it has to provide the
-- 'burst' and 'sustained' throughput measurements for each panelist. These
-- figures are identified in the raw data through the use of the 'sequence'
-- and 'bytes_sec' field.
--
-- Each test from each unit generates 6 rows of data, all with the same
-- timestamp. These six rows have a sequence number from 0-5 (inclusive),
-- and this identifies which 5-second portion of the test that row refers
-- to.
--
-- Specifically:
-- At sequence=0, the value at bytes_sec is the average speed at 0-5s (aka 'burst')
-- At sequence=5, the value at bytes_sec is the average speed at 0-30s
--
-- Note that the 'sustained' speed is not simply the valid at sequence=5. The
-- sustained speed should be for the 25-30s period, so we have to use values from
-- sequence=4 to compute the correct value (effectively the difference between the
-- two). The calculation is therefore:
-- sustained = (bytes_total_5 - bytes_total_4) / (fetch_time_5 - fetch_time_4)
--
-- Note that if there is a less than 3 second difference between sequence 4 and 5,
-- then the difference between sequence 3 and 5 will be used instead.
--
-- This script begins by producing a temporary table containing just the
-- sustained speed measurements. This is used in the main query to find the
-- sustained speed measurements. It is an optimisation more than anything, as it
-- saves us joining back to the same table and scanning 6x as many rows as we need to.
--
-- Like other scripts, this script creates a temporary table of 1st and 99th
-- percentile measurements for each unit at both 'burst' and 'sustained' speeds.
-- These are used by the main query to act as boundaries for the trimmed mean
-- calculation.
--
-- The main query is split into multiple sub-selects, one for each timespan that
-- we want to report on. Each sub-query selects from the httppostmt table at
-- sequence=0 (thus finding our burst speeds) and then joins with the temporary
-- table created earlier (tmp_httpsustained) to get sustained measurements at
-- the same date/time.
--
-- Resulting values are all in bytes-per-second (to convert to Mbit/s just
-- multiply by 0.000008)

DROP TABLE IF EXISTS tmp_httpsustained;
CREATE TABLE tmp_httpsustained (
   u INT(11),
   d DATETIME,
   s DOUBLE,
   INDEX (u,d)
);
INSERT tmp_httpsustained
SELECT unit_id, dtime, bytes_sec_interval
FROM curr_httppostmt
WHERE sequence=5
GROUP BY unit_id, dtime;

DROP TABLE IF EXISTS unit_httppostmt_pct99;
CREATE TABLE unit_httppostmt_pct99 (
  unit_id INT(11),
  burst_perc1 DOUBLE,
  sustained_perc1 DOUBLE,
  burst_perc99 DOUBLE,
  sustained_perc99 DOUBLE,
  INDEX (unit_id)
);
INSERT unit_httppostmt_pct99
SELECT t.unit_id, burst1, sustained1, burst99, sustained99 FROM (SELECT DISTINCT unit_id FROM curr_httppostmt) t
LEFT JOIN (SELECT unit_id, MEDIAN(bytes_sec,2,1) AS burst1, MEDIAN(bytes_sec,2,99) AS burst99 FROM curr_httppostmt WHERE sequence=0 GROUP BY unit_id) b ON b.unit_id = t.unit_id
LEFT JOIN (SELECT u, MEDIAN(s,2,1) AS sustained1, MEDIAN(s,2,99) AS sustained99 FROM tmp_httpsustained GROUP BY u) s ON s.u = t.unit_id;



SELECT u.unit_id,
       a.period, a.burst_min, a.burst_max, a.burst_mean, a.burst_trimmed_mean, a.burst_99_pct, a.burst_median, a.burst_stddev, a.burst_trimmed_stddev, a.sustained_min,
       a.sustained_max, a.sustained_mean, a.sustained_trimmed_mean,
       a.sustained_10_pct, a.sustained_90_pct, a.sustained_20_pct, a.sustained_30_pct, a.sustained_5_pct, a.sustained_95_pct, a.sustained_3_pct, a.sustained_97_pct, 
       a.sustained_99_pct, a.sustained_median, a.sustained_stddev, a.sustained_trimmed_stddev, a.samples,

       b.period, b.burst_min, b.burst_max, b.burst_mean, b.burst_trimmed_mean, b.burst_99_pct, b.burst_median, b.burst_stddev, b.burst_trimmed_stddev, b.sustained_min,
       b.sustained_max, b.sustained_mean, b.sustained_trimmed_mean,
       b.sustained_10_pct, b.sustained_90_pct, b.sustained_20_pct, b.sustained_30_pct, b.sustained_5_pct, b.sustained_95_pct, b.sustained_3_pct, b.sustained_97_pct, 
       b.sustained_99_pct, b.sustained_median, b.sustained_stddev, b.sustained_trimmed_stddev, b.samples,

       c.period, c.burst_min, c.burst_max, c.burst_mean, c.burst_trimmed_mean, c.burst_99_pct, c.burst_median, c.burst_stddev, c.burst_trimmed_stddev, c.sustained_min,
       c.sustained_max, c.sustained_mean, c.sustained_trimmed_mean,
       c.sustained_10_pct, c.sustained_90_pct, c.sustained_20_pct, c.sustained_30_pct, c.sustained_5_pct, c.sustained_95_pct, c.sustained_3_pct, c.sustained_97_pct, 
       c.sustained_99_pct, c.sustained_median, c.sustained_stddev, c.sustained_trimmed_stddev, c.samples,

       d.period, d.burst_min, d.burst_max, d.burst_mean, d.burst_trimmed_mean, d.burst_99_pct, d.burst_median, d.burst_stddev, d.burst_trimmed_stddev, d.sustained_min,
       d.sustained_max, d.sustained_mean, d.sustained_trimmed_mean,
       d.sustained_10_pct, d.sustained_90_pct, d.sustained_20_pct, d.sustained_30_pct, d.sustained_5_pct, d.sustained_95_pct, d.sustained_3_pct, d.sustained_97_pct, 
       d.sustained_99_pct, d.sustained_median, d.sustained_stddev, d.sustained_trimmed_stddev, d.samples,

       e.period, e.sustained_trimmed_mean, e.sustained_trimmed_stddev, e.samples,
       f.period, f.sustained_trimmed_mean, f.sustained_trimmed_stddev, f.samples,
       g.period, g.sustained_trimmed_mean, g.sustained_trimmed_stddev, g.samples,
       h.period, h.sustained_trimmed_mean, h.sustained_trimmed_stddev, h.samples,
       i.period, i.sustained_trimmed_mean, i.sustained_trimmed_stddev, i.samples,
       j.period, j.sustained_trimmed_mean, j.sustained_trimmed_stddev, j.samples,
       k.period, k.sustained_trimmed_mean, k.sustained_trimmed_stddev, k.samples,
       l.period, l.sustained_trimmed_mean, l.sustained_trimmed_stddev, l.samples,
       m.period, m.sustained_trimmed_mean, m.sustained_trimmed_stddev, m.samples,
       n.period, n.sustained_trimmed_mean, n.sustained_trimmed_stddev, n.samples,
       o.period, o.sustained_trimmed_mean, o.sustained_trimmed_stddev, o.samples,
       p.period, p.sustained_trimmed_mean, p.sustained_trimmed_stddev, p.samples

FROM (SELECT DISTINCT unit_id FROM curr_httppostmt) u
LEFT JOIN (
   SELECT t.unit_id, 'Off-Peak Mon-Sun' AS period,
          MIN(bytes_sec) AS burst_min, MAX(bytes_sec) AS burst_max, AVG(bytes_sec) AS burst_mean,
          AVG(IF(bytes_sec < burst_perc1 OR bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_mean, MEDIAN(bytes_sec,2,99) AS burst_99_pct,
          MEDIAN(bytes_sec) AS burst_median, STDDEV(bytes_sec) AS burst_stddev, STDDEV(IF(bytes_sec < burst_perc1 OR bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_stddev, 
          MIN(s.s) AS sustained_min, MAX(s.s) AS sustained_max, AVG(s.s) AS sustained_mean,
          AVG(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, MEDIAN(s.s,2,99) AS sustained_99_pct,
          MEDIAN(s.s,2,10) AS sustained_10_pct, MEDIAN(s.s,2,90) AS sustained_90_pct, MEDIAN(s.s,2,20) AS sustained_20_pct, MEDIAN(s.s,2,30) AS sustained_30_pct,
          MEDIAN(s.s,2,5) AS sustained_5_pct, MEDIAN(s.s,2,95) AS sustained_95_pct, MEDIAN(s.s,2,3) AS sustained_3_pct, MEDIAN(s.s,2,97) AS sustained_97_pct, 
          MEDIAN(s.s) AS sustained_median, STDDEV(s.s) AS sustained_stddev, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev, 
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) NOT IN (19,20,21,22) AND t.sequence=0
   GROUP BY t.unit_id
) a ON u.unit_id = a.unit_id
LEFT JOIN (
   SELECT t.unit_id, '24hr Sat-Sun' AS period,
          MIN(bytes_sec) AS burst_min, MAX(bytes_sec) AS burst_max, AVG(bytes_sec) AS burst_mean,
          AVG(IF(bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_mean, MEDIAN(bytes_sec,2,99) AS burst_99_pct,
          MEDIAN(bytes_sec) AS burst_median, STDDEV(bytes_sec) AS burst_stddev, STDDEV(IF(bytes_sec < burst_perc1 OR bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_stddev, 
          MIN(s.s) AS sustained_min, MAX(s.s) AS sustained_max, AVG(s.s) AS sustained_mean,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, MEDIAN(s.s,2,99) AS sustained_99_pct,
          MEDIAN(s.s,2,10) AS sustained_10_pct, MEDIAN(s.s,2,90) AS sustained_90_pct, MEDIAN(s.s,2,20) AS sustained_20_pct, MEDIAN(s.s,2,30) AS sustained_30_pct,
          MEDIAN(s.s,2,5) AS sustained_5_pct, MEDIAN(s.s,2,95) AS sustained_95_pct, MEDIAN(s.s,2,3) AS sustained_3_pct, MEDIAN(s.s,2,97) AS sustained_97_pct, 
          MEDIAN(s.s) AS sustained_median, STDDEV(s.s) AS sustained_stddev, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev, 
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE dayofweek(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (1,7) AND t.sequence=0
   GROUP BY t.unit_id
) b ON u.unit_id = b.unit_id
LEFT JOIN (
   SELECT t.unit_id, '1900-2200 Mon-Fri' AS period,
          MIN(bytes_sec) AS burst_min, MAX(bytes_sec) AS burst_max, AVG(bytes_sec) AS burst_mean,
          AVG(IF(bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_mean, MEDIAN(bytes_sec,99) AS burst_99_pct,
          MEDIAN(bytes_sec) AS burst_median, STDDEV(bytes_sec) AS burst_stddev, STDDEV(IF(bytes_sec < burst_perc1 OR bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_stddev, 
          MIN(s.s) AS sustained_min, MAX(s.s) AS sustained_max, AVG(s.s) AS sustained_mean,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, MEDIAN(s.s,2,99) AS sustained_99_pct,
          MEDIAN(s.s,2,10) AS sustained_10_pct, MEDIAN(s.s,2,90) AS sustained_90_pct, MEDIAN(s.s,2,20) AS sustained_20_pct, MEDIAN(s.s,2,30) AS sustained_30_pct,
          MEDIAN(s.s,2,5) AS sustained_5_pct, MEDIAN(s.s,2,95) AS sustained_95_pct, MEDIAN(s.s,2,3) AS sustained_3_pct, MEDIAN(s.s,2,97) AS sustained_97_pct, 
          MEDIAN(s.s) AS sustained_median, STDDEV(s.s) AS sustained_stddev, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev, 
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE dayofweek(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (2,3,4,5,6) AND HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (19,20,21,22) AND t.sequence=0
   GROUP BY t.unit_id
) c ON u.unit_id = c.unit_id
LEFT JOIN (
   SELECT t.unit_id, '0900-1600 Mon-Fri' AS period,
          MIN(bytes_sec) AS burst_min, MAX(bytes_sec) AS burst_max, AVG(bytes_sec) AS burst_mean,
          AVG(IF(bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_mean, MEDIAN(bytes_sec,99) AS burst_99_pct,
          MEDIAN(bytes_sec) AS burst_median, STDDEV(bytes_sec) AS burst_stddev, STDDEV(IF(bytes_sec < burst_perc1 OR bytes_sec > burst_perc99, NULL, bytes_sec)) AS burst_trimmed_stddev, 
          MIN(s.s) AS sustained_min, MAX(s.s) AS sustained_max, AVG(s.s) AS sustained_mean,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, MEDIAN(s.s,2,99) AS sustained_99_pct,
          MEDIAN(s.s,2,10) AS sustained_10_pct, MEDIAN(s.s,2,90) AS sustained_90_pct, MEDIAN(s.s,2,20) AS sustained_20_pct, MEDIAN(s.s,2,30) AS sustained_30_pct,
          MEDIAN(s.s,2,5) AS sustained_5_pct, MEDIAN(s.s,2,95) AS sustained_95_pct, MEDIAN(s.s,2,3) AS sustained_3_pct, MEDIAN(s.s,2,97) AS sustained_97_pct, 
          MEDIAN(s.s) AS sustained_median, STDDEV(s.s) AS sustained_stddev, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev, 
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE dayofweek(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (2,3,4,5,6) AND HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (9,10,11,12,13,14,15,16) AND t.sequence=0
   GROUP BY t.unit_id
) d ON u.unit_id = d.unit_id

LEFT JOIN (
   SELECT t.unit_id, '0000-0200 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (0,1)
   GROUP BY t.unit_id
) e ON u.unit_id = e.unit_id
LEFT JOIN (
   SELECT t.unit_id, '0200-0400 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (2,3)
   GROUP BY t.unit_id
) f ON u.unit_id = f.unit_id
LEFT JOIN (
   SELECT t.unit_id, '0400-0600 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (4,5)
   GROUP BY t.unit_id
) g ON u.unit_id = g.unit_id
LEFT JOIN (
   SELECT t.unit_id, '0600-0800 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (6,7)
   GROUP BY t.unit_id
) h ON u.unit_id = h.unit_id
LEFT JOIN (
   SELECT t.unit_id, '0800-1000 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (8,9)
   GROUP BY t.unit_id
) i ON u.unit_id = i.unit_id
LEFT JOIN (
   SELECT t.unit_id, '1000-1200 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (10,11)
   GROUP BY t.unit_id
) j ON u.unit_id = j.unit_id
LEFT JOIN (
   SELECT t.unit_id, '1200-1400 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (12,13)
   GROUP BY t.unit_id
) k ON u.unit_id = k.unit_id
LEFT JOIN (
   SELECT t.unit_id, '1400-1600 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (14,15)
   GROUP BY t.unit_id
) l ON u.unit_id = l.unit_id
LEFT JOIN (
   SELECT t.unit_id, '1600-1800 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (16,17)
   GROUP BY t.unit_id
) m ON u.unit_id = m.unit_id
LEFT JOIN (
   SELECT t.unit_id, '1800-2000 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (18,19)
   GROUP BY t.unit_id
) n ON u.unit_id = n.unit_id
LEFT JOIN (
   SELECT t.unit_id, '2000-2200 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (20,21)
   GROUP BY t.unit_id
) o ON u.unit_id = o.unit_id
LEFT JOIN (
   SELECT t.unit_id, '2200-0000 Mon-Sun' AS period,
          AVG(IF(s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_mean, STDDEV(IF(s.s < sustained_perc1 OR s.s > sustained_perc99, NULL, s.s)) AS sustained_trimmed_stddev,
          SUM(successes+failures) AS samples
   FROM curr_httppostmt t
   INNER JOIN unit_tz ON unit_tz.unit_id = t.unit_id
   LEFT JOIN tmp_httpsustained s ON s.u = t.unit_id AND t.dtime = s.d
   LEFT JOIN unit_httppostmt_pct99 a1 ON t.unit_id = a1.unit_id
   WHERE HOUR(t.dtime + INTERVAL (IF(dtime>'2015-03-11',dst,tz)) HOUR) IN (22,23)
   GROUP BY t.unit_id
) p ON u.unit_id = p.unit_id;

DROP TABLE IF EXISTS tmp_httpsustained;
DROP TABLE IF EXISTS unit_httppostmt_pct99;

